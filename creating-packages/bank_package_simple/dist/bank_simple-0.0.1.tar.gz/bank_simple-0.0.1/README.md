## bank_package_simple

Description.
    This package was an OOP excercise converted in package

## Instalation

Use package manager [pip] (https://pip.pypa.io/en/stable) to install bank_package

## Usage

```python
from bank_package_simple import create_functions
from bank_package_simple import operation_functions
create_functions.cadastrar_usuario(usuario)
```

## Author
Desenvdossa

## License 
MIT

